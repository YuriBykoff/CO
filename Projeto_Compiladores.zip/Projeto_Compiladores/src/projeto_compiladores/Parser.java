package projeto_compiladores;

import java.util.List;

public class Parser {
    
    List<Token> tokens;
    Token token;
    
    public Parser(List<Token> tokens){
        this.tokens = tokens;
    }
    
    public Token nextToken(){
        if(tokens.size() > 0){
            return tokens.remove(0);
        }
        else{
            return null;
        }
    }
    
    public void erro(String regra){
        System.out.println("Regra: " + regra);
        System.out.println("token invalido: " + token);
        System.exit(0);
    }
    
    public void main(){
        token = nextToken();
        if (se()){
            if(token.tipo == "EOF"){
                System.out.println("sintaticamente correto");
            }
            else{
                erro("EOF");
            }
        }
        else{
            erro("chamada se");
        }
    }
    
    public boolean se(){
        if (matchL("se") && condicao() && op_condicional() && matchL("{") && opcaoChaves() && matchL("}") && senaose() && senao()){
            return true;
        }
        erro("se");
        return false;
    }
    
    public boolean condicao(){
        if (matchT("id") && comparacao() && valor()){
            return true;
        }
        erro("condicao");
        return false;
    }
    
    public boolean comparacao(){
        if (matchL("==") || matchL(">=") || matchL("<=") || matchL(">") || matchL("<") || matchL("!=")){
            return true;
        }
        erro("comparacao");
        return false;
    }
    
    public boolean valor(){
        if (matchT("op_decimal") || matchT("num_inteiro") || matchT("id")){
            return true;
        }
        erro("valor");
        return false;
    }
    
    public boolean op_condicional(){
        if (matchL("e") && condicao() && op_condicional2() || matchL("ou") && condicao() && op_condicional2()){
            return true;
        }
        return true;
        //erro("op_condicional");
        //return false;
    }
    
    public boolean op_condicional2(){
        if (op_condicional() && op_condicional2()){
            return true;
        }
        erro("op_condicional2");
        return false;
    }
    
    public boolean opcaoChaves(){
        if (atribuicao() || se()){
            return true;
        }
        erro("opcaoChaves");
        return false;
    }
    
    public boolean atribuicao(){
        if (matchT("id") && matchL("=") && expressao() && matchL(";")){
            return true;
        }
        erro("atribuicao");
        return false;
    }
    
    public boolean expressao(){
        if (termo() && expressao_L()){
            return true;
        }
        erro("expressao");
        return false;
    }
    
    public boolean expressao_L(){
        if ((termo() && expressao_L()) || (matchL("-") && termo() && expressao_L())){
            return true;
        }
        return true;
    }
    
    public boolean termo(){
        if (fator() && termo_L()){
            return true;
        }
        erro("termo");
        return false;
    }
    
    public boolean fator(){
        if (valor() || matchL("(") && expressao() && matchL(")")){
            return true;
        }
        erro("fator");
        return false;
    }
    
    public boolean termo_L(){
        if (matchL("*") && fator() && termo_L() || fator() && termo_L()){
            return true;
        }
        return true;
    }
    
    public boolean senaose(){
        if (matchL("senao_se") && condicao() && op_condicional() && matchL("{") && opcaoChaves() && matchL("}") && senao()){
            return true;
        }
        return true;
    }
    
    public boolean senao(){
        if (matchL("senao") && matchL("{") && opcaoChaves() && matchL("}")){
            return true;
        }
        return true;
    }
    
    public boolean matchL(String lexema){
        if (token.lexema.equals(lexema)){
            token = nextToken();
            return true;
        }
        return false;
    }
    
    public boolean matchT(String tipo){
        if (token.tipo.equals(tipo)){
            token = nextToken();
            return true;
        }
        return false;
    }
}
